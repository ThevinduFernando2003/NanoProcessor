----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 01:37:23 AM
-- Design Name: 
-- Module Name: Mux_8_way_4_bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux_8_way_4_bit is
    Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
           A1 : in STD_LOGIC_VECTOR (3 downto 0);
           A2 : in STD_LOGIC_VECTOR (3 downto 0);
           A3 : in STD_LOGIC_VECTOR (3 downto 0);
           A4 : in STD_LOGIC_VECTOR (3 downto 0);
           A5 : in STD_LOGIC_VECTOR (3 downto 0);
           A6 : in STD_LOGIC_VECTOR (3 downto 0);
           A7 : in STD_LOGIC_VECTOR (3 downto 0);
           S : in STD_LOGIC_VECTOR (2 downto 0);
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end Mux_8_way_4_bit;

architecture Behavioral of Mux_8_way_4_bit is

component Mux_2_way_4_bit
Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
       A1 : in STD_LOGIC_VECTOR (3 downto 0);
       S : in STD_LOGIC;
       Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal q0,q1,q2,q3,q4,q5 : std_logic_vector (3 downto 0);

begin

Mux2way_0 : Mux_2_way_4_bit port map (
A0 => A0,
A1 => A1,
S => S(0),
Q => q0);

Mux2way_1 : Mux_2_way_4_bit port map (
A0 => A2,
A1 => A3,
S => S(0),
Q => q1);

Mux2way_2 : Mux_2_way_4_bit port map (
A0 => A4,
A1 => A5,
S => S(0),
Q => q2);

Mux2way_3 : Mux_2_way_4_bit port map (
A0 => A6,
A1 => A7,
S => S(0),
Q => q3);

Mux2way_4 : Mux_2_way_4_bit port map (
A0 => q0,
A1 => q1,
S => S(1),
Q => q4);

Mux2way_5 : Mux_2_way_4_bit port map (
A0 => q2,
A1 => q3,
S => S(1),
Q => q5);

Mux2way_6 : Mux_2_way_4_bit port map (
A0 => q4,
A1 => q5,
S => S(2),
Q => Q);

end Behavioral;
