----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/19/2025 05:45:57 PM
-- Design Name: 
-- Module Name: Mux_High_Driver - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux_High_Driver is
    Port ( Data_in : in STD_LOGIC_VECTOR (3 downto 0);
           Enable : in STD_LOGIC;
           Data_out : out STD_LOGIC_VECTOR (3 downto 0));
end Mux_High_Driver;

architecture Behavioral of Mux_High_Driver is

begin

process (Data_in, Enable)

    begin
    if Enable = '1' then
        Data_out <= Data_in;
    else 
        Data_out <= "0000";
    end if;

end process;

end Behavioral;
