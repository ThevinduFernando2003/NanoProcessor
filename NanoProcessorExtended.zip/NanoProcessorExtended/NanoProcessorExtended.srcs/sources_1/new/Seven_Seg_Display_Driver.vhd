----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 10:20:22 PM
-- Design Name: 
-- Module Name: Seven_Seg_Display_Driver - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Seven_Seg_Display_Driver is
    Port ( Clk    : in  STD_LOGIC;                    
           Input  : in  STD_LOGIC_VECTOR(3 downto 0);  
           Seg    : out STD_LOGIC_VECTOR(6 downto 0); 
           An     : out STD_LOGIC_VECTOR(3 downto 0));
end Seven_Seg_Display_Driver;

architecture Behavioral of Seven_Seg_Display_Driver is

component SevenSegmentLUT
    Port ( Address : in  STD_LOGIC_VECTOR (3 downto 0);
           Data    : out STD_LOGIC_VECTOR (6 downto 0));
end component;

signal count : INTEGER := 1;
signal clk_status : std_logic := '0';
signal slw_clk        : STD_LOGIC;
signal toggle_refresh  : STD_LOGIC := '0';
signal is_negative     : STD_LOGIC;
signal abs_input       : STD_LOGIC_VECTOR(3 downto 0);
signal digit0_data     : STD_LOGIC_VECTOR(6 downto 0);
signal digit1_data     : STD_LOGIC_VECTOR(6 downto 0);
signal rom_output      : STD_LOGIC_VECTOR(6 downto 0);

constant minus_char    : STD_LOGIC_VECTOR(6 downto 0) := "0111111"; -- Minus
constant blank_char    : STD_LOGIC_VECTOR(6 downto 0) := "1111111"; -- Blank

begin

process (Clk) begin
    if(rising_edge(Clk)) then
        count <= count+1;
        if (count = 50000) then 
            clk_status <= not clk_status;
            slw_clk <= clk_status;
            count <= 1;
        end if;
    end if;
end process;

process(slw_clk)
    begin
        if rising_edge(slw_clk) then
            toggle_refresh <= not toggle_refresh;
        end if;
end process;

process(Input)
    begin
        if Input(3) = '1' then
            is_negative <= '1';
            abs_input   <= std_logic_vector(unsigned(not Input) + 1);
        else
            is_negative <= '0';
            abs_input   <= Input;
        end if;
end process;

SevenSegmentLUT_0 : SevenSegmentLUT
port map ( Address => abs_input,
           Data    => rom_output);

process(is_negative, rom_output)
    begin
        digit0_data <= rom_output;                 
        if is_negative = '1' then
            digit1_data <= minus_char;             
        else
            digit1_data <= blank_char;             
        end if;
end process;

process(toggle_refresh,digit0_data,digit1_data)
    begin
        if toggle_refresh = '0' then
            Seg <= digit0_data;
            An  <= "1110"; -- Enable left digit 
        else
            Seg <= digit1_data;
            An  <= "1101"; -- Enable right digit 
        end if;
end process;

end Behavioral;
