----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/14/2025 01:00:29 PM
-- Design Name: 
-- Module Name: Program_Rom - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Program_Rom is
    Port ( Address : in STD_LOGIC_VECTOR (3 downto 0);
           Data : out STD_LOGIC_VECTOR (13 downto 0));
end Program_Rom;

architecture Behavioral of Program_Rom is

type rom_type is array (0 to 15) of STD_LOGIC_VECTOR (13 downto 0);

    signal PROGRAM_ROM: rom_type := (
        "00101110000001", -- MOVI R7,1
        "00100010000010", -- MOVI R1,2 
        "00001110010000", -- ADD R7,R1
        "10011110010000", -- SUB R7,R1
        "01011110010000", -- MUL R7,R1
        "00110000000111", -- JZR R0,7
        "00100011000010", -- MOVI R3,2
        "01000000001001", -- JMP 9
        "00101000000001", -- MOVI R4,1
        "00010010000000", -- NEG R1
        "01101110010000", -- COMP R7,R1
        "00101010000011", -- MOVI R5,3
        "01101111010000", -- COMP R7,R5
        "10111111010000", -- OR R7,R1
        "10000000000000", -- NOP
        "10101110010000"  -- AND R7,R1
        );
        
begin

Data <= PROGRAM_ROM(to_integer(unsigned(Address)));

end Behavioral;
