----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/14/2025 11:49:50 PM
-- Design Name: 
-- Module Name: TB_Nano_Processor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Nano_Processor is
--  Port ( );
end TB_Nano_Processor;

architecture Behavioral of TB_Nano_Processor is

component Nano_Processor
    Port ( Clk : in STD_LOGIC;
           Reset : in STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC;
           Output_LED : out STD_LOGIC_VECTOR (6 downto 0);
           Output_SevenSegment : out STD_LOGIC_VECTOR (6 downto 0);
           Anode_SevenSegment : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal clk, reset : STD_LOGIC := '0';
signal Overflow,Zero : STD_LOGIC;
signal output_led : STD_LOGIC_VECTOR (6 downto 0);
signal output_sevensegment : STD_LOGIC_VECTOR (6 downto 0);
begin

UUT : Nano_Processor
    port map( Clk => clk,
              Reset => reset,
              Overflow => overflow,
              Zero => zero,
              Output_LED => output_led,
              Output_SevenSegment => output_sevensegment);

process
begin
    wait for 2ns;
    clk <= NOT(clk);
end process;

process
begin
    Reset <= '1';
    wait for 40ns;
    
    Reset <= '0';
    wait;
end process;
         
end Behavioral;
