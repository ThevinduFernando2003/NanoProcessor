----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 12:02:54 AM
-- Design Name: 
-- Module Name: Mux_2_way_4_bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux_2_way_4_bit is
    Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
           A1 : in STD_LOGIC_VECTOR (3 downto 0);
           S : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end Mux_2_way_4_bit;

architecture Behavioral of Mux_2_way_4_bit is

component TriStateBuff

Port ( Data_in : in STD_LOGIC_VECTOR (3 downto 0);
       Enable : in STD_LOGIC;
       Data_out : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal q0,q1 : std_logic_vector (3 downto 0);
signal s1 : std_logic;

begin

s1 <= not S;

A0_Buff : TriStateBuff port map (
Data_in => A0,
Enable => s1,
Data_out => q0);

A1_Buff : TriStateBuff port map (
Data_in => A1,
Enable => S,
Data_out => q1);

Q <= q0 or q1;

end Behavioral;
