----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/02/2025 08:42:32 PM
-- Design Name: 
-- Module Name: Mux_8_Way_4_Bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux_8_Way_4_Bit is
    Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
           A1 : in STD_LOGIC_VECTOR (3 downto 0);
           A2 : in STD_LOGIC_VECTOR (3 downto 0);
           A3 : in STD_LOGIC_VECTOR (3 downto 0);
           A4 : in STD_LOGIC_VECTOR (3 downto 0);
           A5 : in STD_LOGIC_VECTOR (3 downto 0);
           A6 : in STD_LOGIC_VECTOR (3 downto 0);
           A7 : in STD_LOGIC_VECTOR (3 downto 0);
           S : in STD_LOGIC_VECTOR (2 downto 0);
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end Mux_8_Way_4_Bit;

architecture Behavioral of Mux_8_Way_4_Bit is

component Decoder_3_to_8
    port(   I : in STD_LOGIC_VECTOR (2 downto 0);
            EN : in STD_LOGIC;
            Y : out STD_LOGIC_VECTOR (7 downto 0));
end component;

component TriStateBuff
    port ( Data_in : in STD_LOGIC_VECTOR (3 downto 0);
           Enable : in STD_LOGIC;
           Data_out : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal Y_Sig : STD_LOGIC_VECTOR (7 downto 0);

begin

Decoder_3_to_8_0 : Decoder_3_to_8
    port map (  I => S,
                EN => '1',
                Y => Y_Sig);
                
TriStateBuff_0 : TriStateBuff
    port map (  Data_in => A0,
                Enable => Y_Sig(0),
                Data_out => Q);

TriStateBuff_1 : TriStateBuff
    port map (  Data_in => A1,
                Enable => Y_Sig(1),
                Data_out => Q);

TriStateBuff_2 : TriStateBuff
    port map (  Data_in => A2,
                Enable => Y_Sig(2),
                Data_out => Q);
                
TriStateBuff_3 : TriStateBuff
    port map (  Data_in => A3,
                Enable => Y_Sig(3),
                Data_out => Q);

TriStateBuff_4 : TriStateBuff
    port map (  Data_in => A4,
                Enable => Y_Sig(4),
                Data_out => Q);

TriStateBuff_5 : TriStateBuff
    port map (  Data_in => A5,
                Enable => Y_Sig(5),
                Data_out => Q);

TriStateBuff_6 : TriStateBuff
    port map (  Data_in => A6,
                Enable => Y_Sig(6),
                Data_out => Q);
                
TriStateBuff_7 : TriStateBuff
    port map (  Data_in => A7,
                Enable => Y_Sig(7),
                Data_out => Q);
                
end Behavioral;
