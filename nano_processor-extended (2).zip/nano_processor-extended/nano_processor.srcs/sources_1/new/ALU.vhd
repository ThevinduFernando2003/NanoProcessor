----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 09:48:26 AM
-- Design Name: 
-- Module Name: ALU - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           ALU_Selector : in STD_LOGIC_VECTOR (2 downto 0);
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC;
           A_Less : out STD_LOGIC;
           A_Equal : out STD_LOGIC;
           A_Greater : out STD_LOGIC);
end ALU;

architecture Behavioral of ALU is

component AddSub
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end component;

component Comparator_4_bit
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           A_Less : out STD_LOGIC;
           A_Equal : out STD_LOGIC;
           A_Greater : out STD_LOGIC);
end component;

component Multiplier_2
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component NOT_Operator
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component NOP_Operator
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal s0,s1,s2,s3 : STD_LOGIC_VECTOR (3 downto 0);

begin

AddSub_0 : AddSub
port map( A => A,
          B => B,
          M => M,
          S => s0,
          Cout => Cout,
          Overflow => Overflow,
          Zero => Zero);

Comparator_4_bit_0 : Comparator_4_bit
port map ( A => A,
           B => B,
           A_Less => A_Less,
           A_Equal => A_Equal,
           A_Greater => A_Greater);
           
Multiplier_2_0 : Multiplier_2
port map ( A => A,
           B => B,
           Y => s1);

NOT_Operator_0 : NOT_Operator
port map ( A => A,
           Y => s2);

NOP_Operator_0 : NOP_Operator
port map ( A => A,
           Y => s3);   
                  
process(ALU_Selector, s0, s1, s2, s3)
begin
    case ALU_Selector is
        when "000" =>  -- Addition/Subtraction
            S <= s0;
        when "001" =>  -- Multiplication
            S <= s1;
        when "010" =>  -- NOT
            S <= s2;
        when "011" =>  -- NOP
            S <= s2;
        when others =>
            S <= (others => '0');  -- Default
    end case;
end process;        
end Behavioral;
