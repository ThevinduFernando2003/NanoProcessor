----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/14/2025 01:00:29 PM
-- Design Name: 
-- Module Name: Program_Rom - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Program_Rom is
    Port ( Address : in STD_LOGIC_VECTOR (3 downto 0);
           Data : out STD_LOGIC_VECTOR (13 downto 0));
end Program_Rom;

architecture Behavioral of Program_Rom is

type rom_type is array (0 to 15) of STD_LOGIC_VECTOR (13 downto 0);

    signal PROGRAM_ROM: rom_type := (
        "00101110000001",
        "00100010000010",
        "00100100000011",
        "00001110010000",
        "00001110100000",
        "01010010100000",
        "01101110100000",
        "01000000001010",
        "00000000000000",
        "00000000000000",
        "01110010000000",
        "10000000000000",
        "00100110000001",
        "10010100110000",
        "00000000000000",
        "00110000000000"
        );
        
begin

Data <= PROGRAM_ROM(to_integer(unsigned(Address)));

end Behavioral;
