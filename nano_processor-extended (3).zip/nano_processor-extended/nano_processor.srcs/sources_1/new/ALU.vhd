----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 09:48:26 AM
-- Design Name: 
-- Module Name: ALU - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           ALU_Selector : in STD_LOGIC_VECTOR (2 downto 0);
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC;
           A_Less : out STD_LOGIC;
           A_Equal : out STD_LOGIC;
           A_Greater : out STD_LOGIC);
end ALU;

architecture Behavioral of ALU is

component AddSub
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end component;

component Comparator_4_bit
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           A_Less : out STD_LOGIC;
           A_Equal : out STD_LOGIC;
           A_Greater : out STD_LOGIC);
end component;

component Multiplier_2
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component NOT_Operator
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           Y : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal s0,s1,s2,s3,s4 : STD_LOGIC_VECTOR (3 downto 0);
signal as0,as1,as2 : STD_LOGIC;

begin

AddSub_0 : AddSub
port map( A => A,
          B => B,
          M => M,
          S => s0,
          Cout => as0,
          Overflow => as1,
          Zero => as2);

Multiplier_2_0 : Multiplier_2
port map ( A => A,
           B => B,
           Y => s1);
           
Comparator_4_bit_0 : Comparator_4_bit
port map ( A => A,
           B => B,
           A_Less => s2(0),
           A_Equal => s2(1),
           A_Greater => s2(2));

NOT_Operator_0 : NOT_Operator
port map ( A => A,
           Y => s3);
                  
process(ALU_Selector, s0,s1,s2,s3,s4,as0,as1,as2)
begin
        s <= "0000";
        Overflow <= '0';
        A_Less <= '0';
        A_Equal <= '0';
        A_Greater <= '0';
        Cout <= '0';
        Overflow <= '0';
        Zero <= '0';
        
    case ALU_Selector is
        when "000" =>  -- Addition/Subtraction
            S <= s0;
            Cout <= as0;
            Overflow <= as1;
            Zero <= as2;
        when "001" =>  -- Multiplication
            S <= s1;
        when "010" =>  -- COM
            A_Less <= s2(0);
            A_Equal <= s2(1);
            A_Greater <= s2(2);
        when "011" =>  -- NOT
            S <= s3;
        when "100" =>  -- NOP
            S <= "0000";
        when others =>
            S <= (others => '0');  -- Default
    end case;
end process;        
end Behavioral;
