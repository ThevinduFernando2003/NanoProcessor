----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/18/2025 02:58:32 AM
-- Design Name: 
-- Module Name: TriStateBuff_3bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TriStateBuff_3bit is
    Port ( Data_in : in STD_LOGIC_VECTOR (2 downto 0);
           Enable : in STD_LOGIC;
           Data_out : out STD_LOGIC_VECTOR (2 downto 0));
end TriStateBuff_3bit;

architecture Behavioral of TriStateBuff_3bit is

begin

process (Data_in, Enable)

begin

if Enable = '1' then
Data_out <= Data_in;

else 
Data_out <= "ZZZ";

end if;

end process;


end Behavioral;
