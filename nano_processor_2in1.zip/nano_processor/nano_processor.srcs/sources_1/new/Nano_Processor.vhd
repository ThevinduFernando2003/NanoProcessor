----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/14/2025 08:01:31 PM
-- Design Name: 
-- Module Name: Nano_Processor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Nano_Processor is
    Port ( Clk : in STD_LOGIC;
           Reset : in STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC;
           Output_LED : out STD_LOGIC_VECTOR (3 downto 0);
           Output_SevenSegment : out STD_LOGIC_VECTOR (6 downto 0);
           Anode_SevenSegment : out STD_LOGIC_VECTOR (3 downto 0));
end Nano_Processor;

architecture Behavioral of Nano_Processor is

component Slow_Clk 
    Port ( Clk_in : in STD_LOGIC;
           Clk_out : out STD_LOGIC);
end component;

component Register_Bank
    Port ( D : in STD_LOGIC_VECTOR (3 downto 0);
           I : in STD_LOGIC_VECTOR (2 downto 0);
           Clk : in STD_LOGIC;
           Clr : in STD_LOGIC;
           R0 : out STD_LOGIC_VECTOR (3 downto 0);
           R1 : out STD_LOGIC_VECTOR (3 downto 0);
           R2 : out STD_LOGIC_VECTOR (3 downto 0);
           R3 : out STD_LOGIC_VECTOR (3 downto 0);
           R4 : out STD_LOGIC_VECTOR (3 downto 0);
           R5 : out STD_LOGIC_VECTOR (3 downto 0);
           R6 : out STD_LOGIC_VECTOR (3 downto 0);
           R7 : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Mux_2_Way_3_bit
    Port ( A0 : in STD_LOGIC_VECTOR (2 downto 0);
           A1 : in STD_LOGIC_VECTOR (2 downto 0);
           S : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Mux_2_Way_4_bit
    Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
           A1 : in STD_LOGIC_VECTOR (3 downto 0);
           S : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Mux_8_Way_4_Bit
    Port ( A0 : in STD_LOGIC_VECTOR (3 downto 0);
           A1 : in STD_LOGIC_VECTOR (3 downto 0);
           A2 : in STD_LOGIC_VECTOR (3 downto 0);
           A3 : in STD_LOGIC_VECTOR (3 downto 0);
           A4 : in STD_LOGIC_VECTOR (3 downto 0);
           A5 : in STD_LOGIC_VECTOR (3 downto 0);
           A6 : in STD_LOGIC_VECTOR (3 downto 0);
           A7 : in STD_LOGIC_VECTOR (3 downto 0);
           S : in STD_LOGIC_VECTOR (2 downto 0);
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component AddSub
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Cout : out STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end component;

component Adder_3_Bit
    Port ( A : in STD_LOGIC_VECTOR (2 downto 0);
           S : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Program_Counter
    Port ( D : in STD_LOGIC_VECTOR (2 downto 0);
           Res : in STD_LOGIC;
           Clk : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Instruction_Decoder
    Port ( Ins_Bus : in STD_LOGIC_VECTOR (11 downto 0);
           Reg_Ch_Jump : in STD_LOGIC_VECTOR (3 downto 0);
           Reg_Enable : out STD_LOGIC_VECTOR (2 downto 0);
           Load_Sel : out STD_LOGIC;  -- 1 when immediate value
           Imm_Value : out STD_LOGIC_VECTOR (3 downto 0);
           Reg_Sel_1 : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_2 : out STD_LOGIC_VECTOR (2 downto 0);
           Add_Sub_Sel : out STD_LOGIC; -- add - 0
           Jump_Flag : out STD_LOGIC;
           Address_Jump : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Program_Rom
    Port ( Address : in STD_LOGIC_VECTOR (2 downto 0);
           Data : out STD_LOGIC_VECTOR (11 downto 0));
end component;

component Seven_Seg_Display_Driver
    Port ( Clk    : in  STD_LOGIC;                    
           Input  : in  STD_LOGIC_VECTOR(3 downto 0);  
           Seg    : out STD_LOGIC_VECTOR(6 downto 0); 
           An     : out STD_LOGIC_VECTOR(3 downto 0));
end component;

signal zero_0,overflow_0,slw_clk,add_sub_sel,carry_out,load_sel,jump_flag: STD_LOGIC;
signal reg_enable,pc_mem_add,adder_out,pointer,reg_sel_1,address_jump,reg_sel_2: STD_LOGIC_VECTOR (2 downto 0);
signal reg_bank_input,data_bus_0,data_bus_1,data_bus_2,data_bus_3,data_bus_4,data_bus_5,data_bus_6,data_bus_7,to_addsub_1,to_addsub_2,result,imm_value : STD_LOGIC_VECTOR (3 downto 0);
signal instruction_bus : STD_LOGIC_VECTOR (11 downto 0);

begin
        
Slow_Clk_0 : Slow_Clk
    port map ( Clk_in=> Clk,
               Clk_out => slw_clk);
    
Register_Bank_0 : Register_Bank
    port map( D => reg_bank_input,
              I => reg_enable,
              Clk => slw_clk,
              Clr => Reset,
              R0 => data_bus_0,
              R1 => data_bus_1,
              R2 => data_bus_2,
              R3 => data_bus_3,
              R4 => data_bus_4,
              R5 => data_bus_5,
              R6 => data_bus_6,
              R7 => data_bus_7); 
              
Program_Counter_0 : Program_Counter
    port map( D => pointer,
              Res => Reset,
              Clk => slw_clk,
              Q => pc_mem_add);
    
Program_Rom_0 : Program_Rom
    port map ( Address => pc_mem_add ,
               Data => instruction_bus);
  
Instruction_Decoder_0 : Instruction_Decoder
    port map( Ins_Bus => instruction_bus,
              Reg_Ch_Jump => to_addsub_1,
              Reg_Enable => reg_enable,
              Load_Sel => load_sel,
              Imm_value => imm_value,
              Reg_Sel_1 => reg_sel_1,
              Reg_Sel_2  => reg_sel_2,
              Add_Sub_Sel => add_sub_sel,
              Jump_Flag => jump_flag,
              Address_Jump => address_jump);    

Mux_2_Way_3_bit_0 : Mux_2_Way_3_bit
    port map( A0 => adder_out,
              A1 => address_jump,
              S => jump_flag,
              Q => pointer);

Mux_2_Way_4_bit_0 : Mux_2_Way_4_bit
    port map( A0 => result,
              A1 => imm_value,
              S => load_sel,
              Q => reg_bank_input);

Mux_8_Way_4_bit_0 : Mux_8_Way_4_bit
    port map( A0 => data_bus_0,
              A1 => data_bus_1,
              A2 => data_bus_2,
              A3 => data_bus_3,
              A4 => data_bus_4,
              A5 => data_bus_5,
              A6 => data_bus_6,
              A7 => data_bus_7,
              S => reg_sel_1,
              Q => to_addsub_1);

Mux_8_Way_4_bit_1 : Mux_8_Way_4_bit
    port map( A0 => data_bus_0,
              A1 => data_bus_1,
              A2 => data_bus_2,
              A3 => data_bus_3,
              A4 => data_bus_4,
              A5 => data_bus_5,
              A6 => data_bus_6,
              A7 => data_bus_7,
              S  => reg_sel_2,
              Q  => to_addsub_2);
              
AddSub_0 : AddSub
    port map( A => to_addsub_1,
              B => to_addsub_2,
              M => add_sub_sel,
              S => result,
              Cout => carry_out,
              Overflow => overflow_0,
              Zero => zero_0);

Adder_3_Bit_0 : Adder_3_Bit
    port map ( A => pc_mem_add,
               S => adder_out);    

Seven_Seg_Display_Driver_0 : Seven_Seg_Display_Driver
port map ( Clk => Clk,
           Input => data_bus_7,
           Seg => Output_SevenSegment,
           An => Anode_SevenSegment);

process(instruction_bus(11 downto 10))
    begin
        if(instruction_bus(11 downto 10) = "00") OR (instruction_bus(11 downto 10) = "01") then
            Zero <= zero_0;
            Overflow <= overflow_0;
        end if;
end process;       
        
Output_LED <= data_bus_7;

end Behavioral;
